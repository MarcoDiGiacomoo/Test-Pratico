--Creo un DataBase con nome ToysGroup

CREATE DATABASE ToysGroup

--Creo le tabelle all' interno del DB

CREATE TABLE DimCategory (
CategoryKey INT NOT NULL,
CategoryAlternateKey INT,
CategoryName VARCHAR(15),
CONSTRAINT PK_DimCategory PRIMARY KEY (CategoryKey))

CREATE TABLE DimProduct (
ProductKey INT NOT NULL,
ProductAlternateKey INT,
ProductName VARCHAR(25),
CategoryKey INT,
CONSTRAINT PK_DimProduct PRIMARY KEY (ProductKey),
CONSTRAINT FK_DimCategory_DimProduct FOREIGN KEY (CategoryKey) REFERENCES DimCategory(CategoryKey)
)

CREATE TABLE DimRegion (
SalesRegionKey INT NOT NULL,
SalesRegionName VARCHAR(25)
CONSTRAINT PK_DimRegion PRIMARY KEY (SalesRegionKey)
)

CREATE TABLE DimState (
StateKey INT NOT NULL,
SalesRegionKey INT,
StateName VARCHAR(25),
CONSTRAINT PK_DimState PRIMARY KEY (StateKey),
CONSTRAINT FK_DimRegion_DimState FOREIGN KEY (SalesRegionKey) REFERENCES DimRegion(SalesRegionKey)
)

CREATE TABLE FactSales (
OrderNumber INT NOT NULL,
OrderLineNumber INT NOT NULL,
ProductKey INT,
StateKey INT,
UnitPrice DECIMAL(5,2),
Quantity INT,
SalesAmount DECIMAL(6,2),
OrderDate DATE,
CONSTRAINT PK_FactSales PRIMARY KEY (OrderNumber, OrderLineNumber),
CONSTRAINT FK_DimProduct_FactSales FOREIGN KEY (ProductKey) REFERENCES DimProduct(ProductKey),
CONSTRAINT FK_DimState_FactSales FOREIGN KEY (StateKey) REFERENCES DimState(StateKey)
)

--Inserisco i dati nelle tabelle, a parte category ho inserito tutto manualmente per essere il pi� coerente possibile con la traccia
--ho riempito il campo OrderDate di FactSales in modo casuale, Facendo attenzione al campo OrderNumber

SELECT * 
FROM DimCategory

INSERT INTO DimCategory
SELECT ProductCategoryKey, ProductCategoryAlternateKey, EnglishProductCategoryName
FROM AdventureWorksDW2019.dbo.DimProductCategory

SELECT *
FROM DimProduct

INSERT INTO DimProduct
VALUES (1, 1, 'Costume di Spiderman', 3),
(2, 2, 'Bicicletta Rosa', 1),
(3, 3, 'Joystick', 4),
(4, 4, 'Bicicletta Nera', 1),
(5, 5, 'Dadi Monopoli', 4),
(6, 6, 'Memory Card 30 MB', 2),
(7, 7, 'Costume di Barbie', 3),
(8, 8, 'Cuffie Bluetooth', 4),
(9, 9, 'Memory Card 15 MB',2),
(10, 10, 'Astuccio DragonBall', 4)

SELECT *
FROM DimState

INSERT INTO DimState
VALUES (1, 1, 'Stati Uniti'),
(2, 1, 'Canada'),
(3, 1, 'Messico'),
(4, 1, 'Brasile'),
(5, 1, 'Argentina'),
(6, 3, 'Italia'),
(7, 3, 'Francia'),
(8, 3, 'Germania'),
(9, 3, 'Spagna'),
(10, 5, 'Giappone'),
(11, 5, 'Cina'),
(12, 2, 'Australia'),
(13, 5, 'India'),
(14, 2, 'Indonesia'),
(15, 4, 'Nigeria'),
(16, 4, 'Egitto'),
(17, 3, 'Regno Unito'),
(18, 5, 'Arabia Suadita'),
(19, 3, 'Portogallo'),
(20, 4, 'Algeria')

SELECT *
FROM DimRegion

INSERT INTO DimRegion
VALUES (1, 'America'),
(2, 'Oceania'),
(3, 'Europa'),
(4, 'Africa'),
(5, 'Asia')

SELECT *
FROM FactSales

INSERT INTO FactSales 
VALUES ( 1, 1, 1, 6, 12.4, 1, 12.4, '2024-01-13'),
( 1, 2, 10, 6, 35.9, 1, 35.9, '2024-01-13'),
( 1, 3, 6, 6, 17.9, 1, 17.9, '2024-01-12'),
( 2, 1, 3, 2, 11.9, 1, 11.9, '2023-11-18'),
( 3, 1, 7, 1, 25.9, 1, 25.9, '2023-07-09'),
( 4, 1, 10, 15, 35.9, 1, 35.9, '2024-01-16'),
( 5, 1, 3, 13, 11.9, 1, 11.9, '2023-05-30'),
( 5, 2, 9, 13, 9.9, 1, 9.9, '2023-05-30'),
( 6, 1, 8, 6, 10.0, 1, 10.0, '2024-01-17'),
( 7, 1, 10, 9, 35.9, 1, 35.9, '2023-03-09'),
( 7, 2, 3, 9, 11.9, 1, 11.9, '2023-03-09'),
( 7, 3, 2, 9, 9.9, 1, 9.9, '2023-03-09'),
( 8, 1, 10, 17, 35.9, 1, 35.9, '2024-01-24'),
( 9, 1, 7, 3, 25.9, 1, 25.9, '2023-12-31'),
( 10, 1, 6, 5, 17.9, 1, 17.9, '2024-01-01'),
( 11, 1, 8, 7, 10.0, 1, 10.0, '2023-01-30'),
( 12, 1, 2, 18, 9.9, 1, 9.9, '2023-08-15'),
( 12, 2, 4, 18, 10.9, 1, 10.9, '2023-08-15'),
( 13, 1, 7, 4, 25.9, 1, 25.9, '2024-01-15'),
( 14, 1, 8, 5, 10.9, 1, 10.9, '2024-01-12')

/*
1)	Verificare che i campi definiti come PK siano univoci. In altre parole, scrivi una query per determinare l�univocit� 
      dei valori di ciascuna PK (una query per tabella implementata).
*/

SELECT CategoryKey, COUNT(CategoryKey) AS Conteggio
FROM DimCategory
GROUP BY CategoryKey
HAVING COUNT(CategoryKey) > 1

SELECT ProductKey, COUNT(ProductKey) AS Conteggio
FROM DimProduct
GROUP BY ProductKey
HAVING COUNT(ProductKey) > 1

SELECT SalesRegionKey, COUNT(SalesRegionKey) AS Conteggio
FROM DimRegion
GROUP BY SalesRegionKey
HAVING COUNT(SalesRegionKey) > 1

SELECT StateKey, COUNT(StateKey) AS Conteggio
FROM DimState
GROUP BY StateKey
HAVING COUNT(StateKey) > 1

SELECT OrderNumber,  OrderLineNumber, COUNT(OrderNumber) AS Conteggio
FROM FactSales
GROUP BY OrderNumber, OrderLineNumber
HAVING COUNT(OrderNumber) > 1

/*
2)	Esporre l�elenco delle transazioni indicando nel result set il codice documento, la data, il nome del prodotto, la categoria del prodotto, 
    il nome dello stato, il nome della regione di vendita e un campo booleano valorizzato in base alla condizione che siano passati 
    pi� di 180 giorni dalla data vendita o meno (>180 -> True, <= 180 -> False)

-  Per crearmi la fonte dati devo fare una serie di JOIN per collegare le 5 tabelle
-  Per crearmi il campo FLAG uso CASE e la funzione DATEDIFF che mi calcola la differenza tra le date passate come oggetto
*/

SELECT f.OrderNumber, f.OrderLineNumber, f.OrderDate, p.ProductName, c.CategoryName, s.StateName, r.SalesRegionName,
       CASE WHEN DATEDIFF(DAY, f.OrderDate, GETDATE()) > 180 THEN 'TRUE' ELSE 'FALSE' END AS FlagGiorniVendita
FROM FactSales AS f
INNER JOIN DimState AS s
ON f.StateKey = s.StateKey
INNER JOIN DimRegion AS r
ON s.SalesRegionKey = r.SalesRegionKey
INNER JOIN DimProduct AS p
ON f.ProductKey = p.ProductKey
INNER JOIN DimCategory AS c
ON p.CategoryKey = c.CategoryKey

/*
3)	Esporre l�elenco dei soli prodotti venduti e per ognuno di questi il fatturato totale per anno. 
*/

SELECT *
FROM FactSales

SELECT *
FROM DimProduct

SELECT s.ProductKey, p.ProductName, YEAR(s.OrderDate) AS Anno, SUM(s.SalesAmount) AS Tot_Fatturato
FROM FactSales AS s
INNER JOIN DimProduct AS p
ON s.ProductKey = p.ProductKey
GROUP BY s.ProductKey, p.ProductName, YEAR(s.OrderDate)

/*
4)	Esporre il fatturato totale per stato per anno. Ordina il risultato per data e per fatturato decrescente.

    Uso una RIGHT JOIN in modo da riuscire a vedere anche quegli stati (se ci sono) in cui non sono state effettuate delle vendite.
	In alcuni casi il campo StateKey � NULL, ci� accade perch� nella tabella FactSales alcuni paesi non compaiono
	per cui il campo viene StateKey viene settato in automatico con NULL
*/

SELECT *
FROM FactSales

SELECT *
FROM DimState

SELECT f.StateKey, s.StateName, YEAR(f.OrderDate) AS Anno, SUM(f.SalesAmount) AS Fatturato
FROM FactSales AS f
RIGHT OUTER JOIN DimState AS s
ON f.StateKey = s.StateKey
GROUP BY f.StateKey, s.StateName, YEAR(f.OrderDate)
ORDER BY YEAR(f.OrderDate), Fatturato DESC

/*
5)	Rispondere alla seguente domanda: qual � la categoria di articoli maggiormente richiesta dal mercato?

Per trovare la categoria di prodotti pi� venduta devo:
- effettuare un JOIN MULTIPLA: la prima tra FactSales e DimProduct per trovare i prodotti
  pi� venduti, la seconda tra la tabella risultante dalla JOIN precedente e DimCategory;
- Fare un conteggio delle vendite basandomi sulla categoria di prodotti
*/

SELECT *
FROM FactSales

SELECT *
FROM DimProduct

SELECT *
FROM DimCategory

SELECT c.CategoryKey, c.CategoryName, COUNT(c.CategoryKey) AS VenditeCategoria
FROM FactSales AS s
INNER JOIN DimProduct AS p
ON s.ProductKey = p.ProductKey
INNER JOIN DimCategory AS c
ON p.CategoryKey = c.CategoryKey
GROUP BY c.CategoryKey, c.CategoryName
ORDER BY VenditeCategoria DESC

/*
6)	Rispondere alla seguente domanda: quali sono, se ci sono, i prodotti invenduti? Proponi due approcci risolutivi differenti.

I due approcci sono:
-   una JOIN tra tabelle: Ho usato una LEFT JOIN in modo da avere dei campi NULL (come FactSales.OrderDate e FactSales.ProductKey) 
    e identificare i prodotti non venduti. In questo caso ne � uno soltanto
-   una SELECT innestata 
*/

SELECT *
FROM DimProduct

SELECT *
FROM FactSales

SELECT p.*
FROM DimProduct AS p
LEFT OUTER JOIN FactSales AS s
ON p.ProductKey = s.ProductKey
WHERE s.ProductKey IS NULL

SELECT *
FROM DimProduct
WHERE ProductKey NOT IN (
                         SELECT ProductKey
					     FROM FactSales
					    )

/*
7)	Esporre l�elenco dei prodotti con la rispettiva ultima data di vendita (la data di vendita pi� recente).

Utilizzo una INNER JOIN per mettere in relazione DimProduct e FactSales, un GROUP BY su ProductKey
e la funzione MAX che mi restituisce la data massima (passando come oggetto della funzione il campo OrderDate)
*/

SELECT *
FROM DimProduct

SELECT *
FROM FactSales

SELECT s.ProductKey, MAX(s.OrderDate) AS DataUltimaVendita
FROM FactSales AS s
INNER JOIN DimProduct AS p
ON s.ProductKey = p.ProductKey
GROUP BY s.ProductKey

/*
8)	Creare una vista sui prodotti in modo tale da esporre una �versione denormalizzata� delle informazioni utili (codice prodotto, nome prodotto, nome categoria)
*/
SELECT *
FROM DimProduct

SELECT *
FROM DimCategory

CREATE VIEW VW_MDG_Products AS 
(
SELECT p.ProductKey, p.ProductName, c.CategoryKey, c.CategoryName
FROM DimProduct AS p
INNER JOIN DimCategory AS c
ON p.CategoryKey = c.CategoryKey
);

/*
9)	Creare una vista per restituire una versione �denormalizzata� delle informazioni geografiche
*/

SELECT *
FROM DimState

SELECT *
FROM DimRegion

CREATE VIEW VW_MDG_State AS (
SELECT s.StateKey, s.StateName, r.SalesRegionKey, r.SalesRegionName
FROM DimState AS s
INNER JOIN DimRegion AS r
ON s.SalesRegionKey = r.SalesRegionKey
)